package com.doya.overlay;

import android.app.*;
import android.content.*;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.view.*;
import android.widget.*;

public class OverlayService extends Service {
    private WindowManager wm;
    private View bubble;
    private WindowManager.LayoutParams params;
    private int imageWidth = 190;
    private int imageHeight = 245;

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
        Notification n = new Notification.Builder(this, "doya_overlay")
            .setContentTitle("도야가 화면에 떠 있어요")
            .setContentText("도야 오버레이 실행 중")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .build();
        startForeground(7, n);
        showBubble();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(
                "doya_overlay", "도야 오버레이", NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
    }

    private void showBubble() {
        if (bubble != null) return;
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(5, 5, 5, 5);
        panel.setBackground(roundBackground());

        ImageView portrait = new ImageView(this);
        portrait.setImageResource(R.drawable.doya);
        portrait.setScaleType(ImageView.ScaleType.CENTER_CROP);
        portrait.setClipToOutline(true);
        portrait.setBackground(roundBackground());
        panel.addView(portrait, new LinearLayout.LayoutParams(imageWidth, imageHeight));

        LinearLayout controls = new LinearLayout(this);
        controls.setGravity(Gravity.CENTER);
        Button smaller = new Button(this); smaller.setText("−");
        Button bigger = new Button(this); bigger.setText("+");
        Button close = new Button(this); close.setText("×");
        controls.addView(smaller);
        controls.addView(bigger);
        controls.addView(close);
        panel.addView(controls);

        smaller.setOnClickListener(v -> resize(-25, portrait));
        bigger.setOnClickListener(v -> resize(25, portrait));
        close.setOnClickListener(v -> stopSelf());

        int type = Build.VERSION.SDK_INT >= 26
            ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            : WindowManager.LayoutParams.TYPE_PHONE;
        params = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 24;
        params.y = 180;

        // 사진 영역을 드래그할 때만 이동시켜 아래 크기/닫기 버튼이 정상 작동하게 함
        portrait.setOnTouchListener(new View.OnTouchListener() {
            int startX, startY;
            float touchX, touchY;
            @Override public boolean onTouch(View v, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) {
                    startX = params.x; startY = params.y;
                    touchX = e.getRawX(); touchY = e.getRawY();
                    return true;
                }
                if (e.getAction() == MotionEvent.ACTION_MOVE) {
                    params.x = startX + (int)(e.getRawX() - touchX);
                    params.y = startY + (int)(e.getRawY() - touchY);
                    wm.updateViewLayout(panel, params);
                    return true;
                }
                return e.getAction() == MotionEvent.ACTION_UP;
            }
        });

        bubble = panel;
        wm.addView(bubble, params);
    }

    private GradientDrawable roundBackground() {
        GradientDrawable d = new GradientDrawable();
        d.setColor(0xEEFFFFFF);
        d.setCornerRadius(22f);
        d.setStroke(2, 0x66888888);
        return d;
    }

    private void resize(int delta, ImageView portrait) {
        imageWidth = Math.max(130, Math.min(290, imageWidth + delta));
        imageHeight = Math.max(170, Math.min(370, imageHeight + (int)(delta * 1.29f)));
        portrait.setLayoutParams(new LinearLayout.LayoutParams(imageWidth, imageHeight));
        bubble.requestLayout();
        if (wm != null && bubble != null) wm.updateViewLayout(bubble, params);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override public void onDestroy() {
        if (wm != null && bubble != null) {
            try { wm.removeView(bubble); } catch (Exception ignored) {}
        }
        bubble = null;
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
