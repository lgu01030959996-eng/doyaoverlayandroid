package com.doya.overlay;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int REQUEST_OVERLAY = 1001;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(36, 48, 36, 36);

        TextView title = new TextView(this);
        title.setText("도야 오버레이");
        title.setTextSize(26);

        TextView info = new TextView(this);
        info.setText("다른 앱 위에 도야 사진을 띄우려면 권한이 필요해요. 권한을 허용한 뒤 도야 띄우기를 눌러 주세요.");
        info.setTextSize(16);

        Button permission = new Button(this);
        permission.setText("오버레이 권한 허용");
        permission.setOnClickListener(v -> requestOverlayPermission());

        Button show = new Button(this);
        show.setText("도야 띄우기");
        show.setOnClickListener(v -> {
            if (Settings.canDrawOverlays(this)) startOverlay();
            else requestOverlayPermission();
        });

        root.addView(title);
        root.addView(info);
        root.addView(permission);
        root.addView(show);
        setContentView(root);
    }

    private void requestOverlayPermission() {
        if (!Settings.canDrawOverlays(this)) {
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + getPackageName()));
            startActivityForResult(i, REQUEST_OVERLAY);
        } else {
            startOverlay();
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_OVERLAY && Settings.canDrawOverlays(this)) startOverlay();
    }

    private void startOverlay() {
        Intent i = new Intent(this, OverlayService.class);
        if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(i);
        else startService(i);
    }
}
